package com.mark.oo;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class Msharea extends Fragment implements CustomAdabter.OnItemListener{
View v;
RecyclerView recyclerView;
List<ModelClass> mList;
CustomAdabter customAdabter;

    public Msharea() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       v= inflater.inflate(R.layout.fragment_msharea, container, false);
    recyclerView=v.findViewById(R.id.mshareaRecycler);
customAdabter=new CustomAdabter(mList,getContext());
recyclerView.setAdapter(customAdabter);
recyclerView.setLayoutManager(new LinearLayoutManager( getActivity()));
        String[] some_array = getResources().getStringArray(R.array.proj1);

    return v;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mList=new ArrayList<>();

        mList.add(new ModelClass(R.drawable.gn1,"Plant more trees. ","They clean the air, provide oxygen, and beautify your surroundings.As trees grow, they absorb and store the carbon dioxide emissions that are driving global heating. \nNew research estimates that a worldwide planting programme could remove two-thirds of all the emissions from human activities that remain in the atmosphere today, a figure the scientists describe as “mind-blowing”.\n" +
                "\n" +
                "The analysis found there are 1.7bn hectares of treeless land on which 1.2tn native tree saplings would naturally grow. That area is about 11% of all land and equivalent to the size of the US and China combined. Tropical areas could have 100% tree cover, while others would be more sparsely covered, meaning that on average about half the area would be under tree canopy.",50));
        mList.add(new ModelClass(R.drawable.gn2,"Do not litter ","Start an anti-litter campaign to educate your community.\nLitter consists of waste products that have been discarded incorrectly, without consent, at an unsuitable location. Litter can also be used as a verb; to litter means to drop and leave objects, often man-made, such as aluminum cans, paper cups, fast food wrappers, cardboard boxes or plastic bottles on the ground, and leave them there indefinitely or for other people to dispose of as opposed to disposing of them correctly.\n" +
                "\n" +
                "Large and hazardous items of rubbish such as tires, electrical appliances, electronics, batteries and large industrial containers are sometimes dumped in isolated locations, such as national forests and other public lands.",30));
        mList.add(new ModelClass(R.drawable.gn3,"Encourage the use of green energy ","Try using solar energy which is the most abundant and cleanest source of energy.\nIt can also be argued that conventional energy has received much assistance over the years – be it subsidies to the development of nuclear energy to funding for carbon capture pilot programs for coal power generation, or tax holidays or reduced royalty regimes for oil and gas exploration.\n" +
                "\n" +
                "So what should be done to encourage the development of renewable energy? There are many good examples around the world.\n" +
                "\n" +
                "In the developing world, there are small scale lending programs, such as those provided by the Grameen Bank, which provides loans so that individuals can buy a small solar system to provide energy for charging cellular phones with the usage fees being used to repay the loans.",20));
        mList.add(new ModelClass(R.drawable.gn5,"Buy local foods and goods","In this manner, the use of fuel for transporting goods can be minimized",50));
        mList.add(new ModelClass(R.drawable.gn1,"Carbon footprints need to be reduced!","Lower the temperature of the water heater in your house. Buy energy efficient appliances and reduce the usage of air conditioners, dishwashers or thermostats",10));
        mList.add(new ModelClass(R.drawable.gn2,"Carbon footprints need to be reduced!","Lower the temperature of the water heater in your house. Buy energy efficient appliances and reduce the usage of air conditioners, dishwashers or thermostats",10));
    }

    @Override
    public void onItemClick(int position) {
       mList.get(position);
        Intent intent=new Intent(Msharea.this.getActivity(),ItemActivity.class);
        startActivity(intent);
    }
}
