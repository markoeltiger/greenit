package com.mark.oo;

public class ModelClass {
    int image ;
    String text;
    String text2;
    int point;

    public ModelClass(int image, String text, String text2 ,int poit) {
        this.image = image;
        this.text = text;
        this.text2=text2;
this.point=poit;
    }



    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }

    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }
}
