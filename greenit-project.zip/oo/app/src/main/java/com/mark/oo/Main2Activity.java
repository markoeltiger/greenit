package com.mark.oo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import io.github.kbiakov.codeview.CodeView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.chrisbanes.photoview.PhotoView;

public class Main2Activity extends AppCompatActivity {
private ImageView imageView;
private TextView mytextView;
private TextView mytext2View;
 private Button done;
    SharedPreferences sharedPreferences;
    private TextView chpointss;
    int yourpoinnts;
private int array;
private ListView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getids();

    }
    private void getids(){
        imageView=(ImageView)findViewById(R.id.imageView);
        mytextView=(TextView)findViewById(R.id.image);
        mytext2View=(TextView)findViewById(R.id.tfasel);
            chpointss=(TextView)findViewById(R.id.challenge_points);
done=(Button)findViewById(R.id.done);
        String name =getIntent().getStringExtra("text");
int image=getIntent().getIntExtra("image",0);
String name2=getIntent().getStringExtra("text2");
final int chpoints = getIntent().getIntExtra("point",0);
imageView.setImageResource(image);
mytextView.setText(name);
mytext2View.setText(name2);
chpointss.setText("Complete this challenge and get "+chpoints+" points");
done.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Context context = Main2Activity.this;
        assert context != null;
        sharedPreferences=context.getSharedPreferences("myprefs" , Context.MODE_PRIVATE);
        yourpoinnts=sharedPreferences.getInt("points",0);
        yourpoinnts=yourpoinnts+chpoints;
        SharedPreferences.Editor editor =sharedPreferences.edit();
        editor.putInt("points",yourpoinnts);
        editor.commit();
        Toast.makeText(Main2Activity.this, "Congratulations you took this challenge", Toast.LENGTH_LONG).show();
        Intent mark=new Intent(Main2Activity.this,MainActivity.class);
        startActivity(mark);

    }
});
    }
}
