package com.mark.oo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import io.github.kbiakov.codeview.classifier.CodeProcessor;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
BottomNavigationView bottomNavigationView;
FrameLayout frameLayout;
Dialog myDialog;
EditText emailaddr;
EditText password;
String name;
String age;
SharedPreferences sharedPreferences;
String isfirsttime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences=getSharedPreferences("myprefs" , Context.MODE_PRIVATE);
       isfirsttime=sharedPreferences.getString("key","first1");

        if (isfirsttime.equals("first1")){
        callLoginDialog();}
        CodeProcessor.init(this);
        bottomNavigationView =findViewById(R.id.BottomNavigationView);
        frameLayout=findViewById(R.id.frameLayout);
        SetFragment(new Msharea());

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

             switch (item.getItemId() ){
                 case R.id.msharea:
                     SetFragment(new Msharea());
                     return true;
                 case R.id.mkwnat:
                     SetFragment(new MkwnatFragment());
                     return true;

                 case R.id.contactus:
                     SetFragment(new ContactUs());
                     return true;
                 default:
                     return false;



             }


            }
        });
    }
    private void SetFragment (Fragment fragment){
        FragmentTransaction fragmentTransaction =getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout,fragment);
        fragmentTransaction.commit();
    }
    private void callLoginDialog()
    {
        myDialog = new Dialog(this);
        myDialog.setContentView(R.layout.dialog);
        myDialog.setCancelable(false);
        Button login = (Button) myDialog.findViewById(R.id.yourloginbtnID);
        emailaddr = (EditText) myDialog.findViewById(R.id.youremailID);
        password = (EditText) myDialog.findViewById(R.id.yourpasswordID);

        myDialog.show();

        login.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
                name =emailaddr.getText().toString();
                age=password.getText().toString();
                SharedPreferences.Editor editor =sharedPreferences.edit();
                editor.putString("name",name);
                editor.putInt("points",0);
                editor.putString("age",age);
                editor.putString("key","1");
                editor.commit();
             //   editor.apply();
                myDialog.dismiss();
            }
        });


    }
}
