package com.mark.oo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class MkwnatFragment extends Fragment {
    View v;
    SharedPreferences sharedPreferences;
    String name;
    TextView nametext;
    TextView titletext;
int points;
String title;
    public MkwnatFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

      v= inflater.inflate(R.layout.fragment_mkwnat, container, false);
        nametext=v.findViewById(R.id.namesa);
        ImageView imageView = v.findViewById(R.id.gif);
        ImageView appCompatImageView = v.findViewById(R.id.appCompatImageView);
titletext=v.findViewById(R.id.level);

        Glide.with(this).load(R.drawable.green).into(imageView);
        if (points<50){appCompatImageView.setImageResource(R.drawable.g3);
            title="Greener";}else if (100>points&&points>50){appCompatImageView.setImageResource(R.drawable.g2);title="Good Greener";}else if (100<points){title="Super Greener";appCompatImageView.setImageResource(R.drawable.g1);}
        nametext.setText("Hey "+name +" You have "+ points+" points now"+" and your level is "+title);

        titletext.setText("You Are A "+title);
        return v;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context context = getActivity();
        assert context != null;
        sharedPreferences=context.getSharedPreferences("myprefs" , Context.MODE_PRIVATE);
        name=sharedPreferences.getString("name","NoRegistered");
        points=sharedPreferences.getInt("points",0);

    }
}
